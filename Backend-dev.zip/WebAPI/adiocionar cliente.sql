﻿INSERT INTO TbAddresses (
  nmState,
  nmCity,
  nmStreet,
  nmNeighborhood,
  nrHouseNumber,
  nmComplement,
  nrZipCode
) VALUES (
  'Mato Grosso do Sul',
  'Campo Grande',
  'Rua dos Lírios',
  'Jardim dos Estados',
  663,
  'casa 2',
  '79009220'
);
